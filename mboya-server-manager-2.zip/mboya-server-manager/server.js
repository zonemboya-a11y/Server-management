#!/usr/bin/env node
/*
 * MBOYA SERVER MANAGER  v1.0.0
 * ---------------------------------------------------------------------------
 * The persistent backend that MBOYA SERVER RUNNER connects to (Settings ->
 * Server Manager). It runs REAL processes on the machine it is installed on:
 * Node.js, Python, Java, Go, Rust, PHP, Ruby, .NET, C/C++, Elixir, Dart, Deno,
 * Docker, and static sites - whatever runtimes that machine has installed.
 *
 * The Runner (browser/phone app) can be on ANY device on ANY continent: it only
 * needs this manager's URL + access token. Each deployed project is reverse-
 * proxied under  <manager-url>/p/<project-id>/  so a single public port (or one
 * HTTPS tunnel) is enough for the frontend, the Runner, and your own apps.
 *
 * Zero npm dependencies. Node.js 18+ on Linux / macOS / WSL / Docker.
 * ---------------------------------------------------------------------------
 */
'use strict';
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto'),
  cp = require('child_process'), net = require('net'), os = require('os');

const VERSION = '1.0.0';
const E = process.env;

/* ------------------------------ configuration ------------------------------ */
const PORT = +E.MANAGER_PORT || +E.PORT || 7070;
const HOST = E.MANAGER_HOST || E.HOST || '0.0.0.0';
const DATA = path.resolve(E.DATA_DIR || path.join(__dirname, 'data'));
const PUBLIC_URL = (E.PUBLIC_URL || '').replace(/\/+$/, '');
const URL_MODE = (E.URL_MODE || 'path').toLowerCase();          // path | port
const BIND_CHILD = URL_MODE === 'port' ? '0.0.0.0' : '127.0.0.1'; // interface projects listen on
const PORT_MIN = +E.PROJECT_PORT_MIN || 9000, PORT_MAX = +E.PROJECT_PORT_MAX || 9999;
const MAX_UPLOAD = (+E.MAX_UPLOAD_MB || 300) * 1024 * 1024;
const CORS_ORIGIN = E.CORS_ORIGIN || '*';
const BUILD_TIMEOUT = (+E.BUILD_TIMEOUT_MIN || 20) * 60 * 1000;
const KEEP_VERSIONS = +E.KEEP_VERSIONS || 5;

if (typeof process.getuid === 'function' && process.getuid() === 0 && !E.ALLOW_ROOT && !fs.existsSync('/.dockerenv')) {
  console.error('Refusing to run as root: deployed projects would run with full system access.\n' +
    'Run as a normal user, use the Docker image, or set ALLOW_ROOT=1 if you accept the risk.');
  process.exit(1);
}

fs.mkdirSync(path.join(DATA, 'projects'), { recursive: true });

/* ---------------------------------- token ---------------------------------- */
let TOKEN = E.MANAGER_TOKEN || E.TOKEN || '', tokenCreated = false;
const tokenFile = path.join(DATA, 'token');
if (!TOKEN) {
  if (fs.existsSync(tokenFile)) TOKEN = fs.readFileSync(tokenFile, 'utf8').trim();
  else { TOKEN = crypto.randomBytes(24).toString('hex'); fs.writeFileSync(tokenFile, TOKEN, { mode: 0o600 }); tokenCreated = true; }
}
if (TOKEN.length < 16) { console.error('The access token must be at least 16 characters.'); process.exit(1); }
const TOKEN_HASH = crypto.createHash('sha256').update(TOKEN).digest();
delete E.TOKEN; delete E.MANAGER_TOKEN; // never leak the token into deployed projects

/* ---------------------- encrypted secrets (API keys etc.) ------------------- */
const keyFile = path.join(DATA, 'secret.key');
if (!fs.existsSync(keyFile)) fs.writeFileSync(keyFile, crypto.randomBytes(32), { mode: 0o600 });
const KEY = fs.readFileSync(keyFile);
const enc = s => { const iv = crypto.randomBytes(12), c = crypto.createCipheriv('aes-256-gcm', KEY, iv), b = Buffer.concat([c.update(String(s), 'utf8'), c.final()]); return Buffer.concat([iv, c.getAuthTag(), b]).toString('base64'); };
const dec = s => { const b = Buffer.from(s, 'base64'), d = crypto.createDecipheriv('aes-256-gcm', KEY, b.subarray(0, 12)); d.setAuthTag(b.subarray(12, 28)); return Buffer.concat([d.update(b.subarray(28)), d.final()]).toString('utf8'); };
const secFile = path.join(DATA, 'secrets.json');
let SECRETS = {}; try { SECRETS = JSON.parse(fs.readFileSync(secFile, 'utf8')); } catch (e) { }
const saveSecrets = () => fs.writeFileSync(secFile, JSON.stringify(SECRETS), { mode: 0o600 });
const secretsOf = id => { const o = {}; for (const [k, v] of Object.entries(SECRETS[id] || {})) { try { o[k] = dec(v); } catch (e) { } } return o; };

/* --------------------------------- helpers --------------------------------- */
const sleep = ms => new Promise(r => setTimeout(r, ms));
const q = s => "'" + String(s).replace(/'/g, "'\\''") + "'";
const isoNow = () => new Date().toISOString();
const baseName = p => p.split('/').pop();
const dirOf = p => p.includes('/') ? p.slice(0, p.lastIndexOf('/')) : '';
const jn = (...a) => a.filter(Boolean).join('/').replace(/\/+/g, '/');
class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const hasCmdCache = {};
function hasCmd(name) {
  if (name in hasCmdCache) return hasCmdCache[name];
  let ok = false;
  for (const d of (E.PATH || '').split(path.delimiter)) { try { fs.accessSync(path.join(d, name), fs.constants.X_OK); ok = true; break; } catch (e) { } }
  return hasCmdCache[name] = ok;
}
const fmtUp = ms => { const s = Math.floor(ms / 1000), d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60); return (d ? d + 'd ' : '') + (h ? h + 'h ' : '') + m + 'm ' + (s % 60) + 's'; };

/* --------------------------------- state ---------------------------------- */
const projects = new Map();
const stateFile = path.join(DATA, 'state.json');
let saveT;
function save() {
  clearTimeout(saveT);
  saveT = setTimeout(() => {
    const out = [...projects.values()].map(P => ({
      id: P.id, name: P.name, port: P.port, desired: P.desired, version: P.version, versions: P.versions, cfg: P.cfg, plan: P.plan,
      runtime: P.runtime, kind: P.kind, guess: P.guess, env: P.env, created: P.created, deployedAt: P.deployedAt
    }));
    try { fs.writeFileSync(stateFile + '.tmp', JSON.stringify(out, null, 1)); fs.renameSync(stateFile + '.tmp', stateFile); } catch (e) { console.error('state save failed:', e.message); }
  }, 300);
}
const projDir = id => path.join(DATA, 'projects', id);
const verDir = (id, v) => path.join(projDir(id), 'v' + v);

function newProject(id, name) {
  return {
    id, name, port: null, status: 'STOPPED', desired: 'stopped', version: 0, versions: [], runtime: '', kind: 'process', plan: null, guess: '',
    cfg: { autoRestart: true, mode: 'DEVELOPMENT', healthPath: '/', retries: 3, startupTimeout: 60, startCommand: '', customCommand: false, host: BIND_CHILD, private: false },
    env: {}, logs: [], proc: null, pid: null, exited: true, exitCode: null, startedAt: 0, restarts: [], busy: false, hbFail: 0, created: isoNow(), deployedAt: ''
  };
}
function plog(P, stream, msg) {
  msg = String(msg);
  const secrets = Object.values(secretsOf(P.id)).filter(v => v && v.length >= 4);
  for (const s of secrets) msg = msg.split(s).join('••••');
  const rec = { t: isoNow(), stream, msg };
  P.logs.push(rec); if (P.logs.length > 3000) P.logs.splice(0, P.logs.length - 3000);
  try { fs.appendFileSync(path.join(projDir(P.id), 'logs.txt'), rec.t + ' [' + stream + '] ' + msg + '\n'); } catch (e) { }
}
const tail = (P, n = 8) => P.logs.slice(-n).map(l => l.msg).join(' | ').slice(0, 900);

/* ------------------------- network probes / discovery ------------------------ */
function tcpOpen(port, timeout = 500) {
  return new Promise(res => {
    const s = net.connect({ port, host: '127.0.0.1' }); let done = false;
    const end = v => { if (!done) { done = true; s.destroy(); res(v); } };
    s.setTimeout(timeout, () => end(false)); s.on('connect', () => end(true)); s.on('error', () => end(false));
  });
}
async function freePort(avoid = []) {
  const used = new Set([...projects.values()].map(p => p.port).filter(Boolean).concat(avoid));
  for (let i = 0; i < 2000; i++) {
    const p = PORT_MIN + Math.floor(Math.random() * (PORT_MAX - PORT_MIN + 1));
    if (used.has(p) || p === PORT) continue;
    if (!await tcpOpen(p, 200)) return p;
  }
  throw new HttpError(507, 'No free project port in range ' + PORT_MIN + '-' + PORT_MAX);
}
function listenPorts(pid) { // Linux: ports actually listened on by the project's process group
  if (process.platform !== 'linux' || !pid) return [];
  try {
    const pids = cp.execSync('ps -eo pid=,pgid=', { encoding: 'utf8' }).split('\n').map(l => l.trim().split(/\s+/).map(Number)).filter(x => x[1] === pid).map(x => x[0]);
    const inodes = new Set();
    for (const p of pids) { let fds = []; try { fds = fs.readdirSync('/proc/' + p + '/fd'); } catch (e) { } for (const fd of fds) { try { const m = fs.readlinkSync('/proc/' + p + '/fd/' + fd).match(/^socket:\[(\d+)\]$/); if (m) inodes.add(m[1]); } catch (e) { } } }
    const ports = new Set();
    for (const f of ['/proc/net/tcp', '/proc/net/tcp6']) { try { fs.readFileSync(f, 'utf8').split('\n').slice(1).forEach(l => { const c = l.trim().split(/\s+/); if (c[3] === '0A' && inodes.has(c[9])) ports.add(parseInt(c[1].split(':')[1], 16)); }); } catch (e) { } }
    return [...ports];
  } catch (e) { return []; }
}
function logPorts(P) {
  const out = new Set(); const re = /(?:localhost|127\.0\.0\.1|0\.0\.0\.0|\[::\]|\*)\s*:\s*(\d{2,5})\b|\bport\s*(?:is|=|:)?\s*(\d{2,5})\b/gi;
  for (const l of P.logs.slice(-60)) { let m; while ((m = re.exec(l.msg))) { const n = +(m[1] || m[2]); if (n > 0 && n < 65536) out.add(n); } }
  return [...out];
}
async function adoptPort(P) { // the app ignored $PORT and listens elsewhere -> follow it
  if (!P.pid || await tcpOpen(P.port, 300)) return;
  const cands = listenPorts(P.pid).concat(logPorts(P)).filter(p => p !== P.port && p !== PORT);
  for (const c of cands) if (await tcpOpen(c, 300)) { plog(P, 'manager', 'Application listens on port ' + c + ' (not the assigned ' + P.port + ') - following it'); P.port = c; save(); return; }
}
function httpProbe(port, p, timeout = 4000) {
  return new Promise(async res => {
    const t0 = Date.now(); const ms = () => Date.now() - t0;
    if (!await tcpOpen(port, Math.min(timeout, 1500))) return res({ ok: false, text: 'CONNECTION REFUSED', ms: ms() });
    const r = http.get({ host: '127.0.0.1', port, path: p || '/', timeout, headers: { 'user-agent': 'mboya-manager-health', accept: '*/*' } }, resp => {
      resp.resume(); res({ ok: resp.statusCode < 500, text: resp.statusCode + ' ' + (resp.statusMessage || ''), ms: ms() });
    });
    r.on('timeout', () => { r.destroy(); res({ ok: false, text: 'TIMEOUT', ms: ms() }); });
    r.on('error', () => res({ ok: true, text: 'TCP LISTENING (non-HTTP)', ms: ms(), tcp: true }));
  });
}
const MIME = { html: 'text/html; charset=utf-8', htm: 'text/html; charset=utf-8', css: 'text/css', js: 'text/javascript', mjs: 'text/javascript', json: 'application/json', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', svg: 'image/svg+xml', webp: 'image/webp', ico: 'image/x-icon', txt: 'text/plain; charset=utf-8', woff: 'font/woff', woff2: 'font/woff2', ttf: 'font/ttf', mp3: 'audio/mpeg', mp4: 'video/mp4', wasm: 'application/wasm', map: 'application/json', xml: 'application/xml', pdf: 'application/pdf' };
async function probe(P) {
  if (P.kind === 'static') { const ok = fs.existsSync(path.join(verDir(P.id, P.version), P.plan.docroot || '', 'index.html')) || fs.existsSync(path.join(verDir(P.id, P.version), P.plan.docroot || '')); return { ok, text: ok ? '200 OK (static)' : 'FILES MISSING', ms: 0 }; }
  if (!P.proc || P.exited) return { ok: false, text: 'NOT RUNNING', ms: 0 };
  return httpProbe(P.port, P.cfg.healthPath || '/');
}

/* ------------------------------ process control ------------------------------ */
function procEnv(P) {
  const e = Object.assign({}, process.env);
  delete e.TOKEN; delete e.MANAGER_TOKEN; delete e.DATA_DIR;
  Object.assign(e, (P.plan && P.plan.env) || {}, P.env, secretsOf(P.id));
  e.PORT = String(P.port); e.HOST = BIND_CHILD; e.HOSTNAME = BIND_CHILD; e.BIND = BIND_CHILD;
  e.SERVER_PORT = String(P.port); e.FLASK_RUN_PORT = String(P.port); e.FLASK_RUN_HOST = BIND_CHILD;
  e.NODE_ENV = P.cfg.mode === 'PRODUCTION' ? 'production' : 'development';
  e.PYTHONUNBUFFERED = '1'; e.CI = e.CI || '1';
  return e;
}
function pipeLines(P, stream, s) {
  let buf = '';
  s.on('data', d => { buf += d.toString('utf8'); let i; while ((i = buf.indexOf('\n')) >= 0) { const l = buf.slice(0, i).replace(/\r$/, ''); buf = buf.slice(i + 1); if (l) plog(P, stream, l); } if (buf.length > 20000) { plog(P, stream, buf); buf = ''; } });
  s.on('end', () => { if (buf) plog(P, stream, buf); });
}
function runStep(P, label, cmd, cwd, env) {
  return new Promise((resolve, reject) => {
    plog(P, 'build', '$ ' + cmd + '   (' + label + ')');
    const ch = cp.spawn('/bin/sh', ['-c', cmd], { cwd, env, detached: true, stdio: ['ignore', 'pipe', 'pipe'] });
    pipeLines(P, 'build', ch.stdout); pipeLines(P, 'build', ch.stderr);
    const t = setTimeout(() => { try { process.kill(-ch.pid, 'SIGKILL'); } catch (e) { } reject(new Error(label + ' timed out after ' + Math.round(BUILD_TIMEOUT / 60000) + ' minutes')); }, BUILD_TIMEOUT);
    ch.on('error', e => { clearTimeout(t); reject(new Error(label + ' could not start: ' + e.message)); });
    ch.on('exit', (code, sig) => { clearTimeout(t); code === 0 ? resolve() : reject(new Error(label + ' failed (exit ' + (code === null ? sig : code) + '): ' + tail(P, 6))); });
  });
}
async function startProc(P) {
  if (P.kind === 'static') { P.status = 'SERVING'; P.desired = 'running'; P.startedAt = Date.now(); plog(P, 'manager', 'Static site serving from v' + P.version); save(); return; }
  if (P.proc && !P.exited) return;
  if (!P.plan || !P.plan.start) throw new HttpError(500, 'Nothing to start: this project has no start command');
  if (await tcpOpen(P.port, 300)) { const np = await freePort(); plog(P, 'manager', 'Port ' + P.port + ' is busy - using ' + np + ' instead'); P.port = np; }
  const cwd = path.join(verDir(P.id, P.version), P.plan.cwd || '');
  const cmd = String(P.plan.start).replace(/(?<=[\s:=])PORT(?=$|[\s'":])/g, String(P.port));
  const sh = /&&|\|\||[;|]/.test(cmd) ? cmd : 'exec ' + cmd;
  plog(P, 'manager', 'Starting v' + P.version + ' on port ' + P.port + ': ' + cmd);
  P.status = 'STARTING'; P.exited = false; P.exitCode = null; P._stopping = false;
  const ch = cp.spawn('/bin/sh', ['-c', sh], { cwd, env: procEnv(P), detached: true, stdio: ['ignore', 'pipe', 'pipe'] });
  P.proc = ch; P.pid = ch.pid; P.startedAt = Date.now(); P.desired = 'running';
  pipeLines(P, 'stdout', ch.stdout); pipeLines(P, 'stderr', ch.stderr);
  ch.on('error', e => { plog(P, 'manager', 'spawn error: ' + e.message); });
  ch.on('exit', (code, sig) => {
    if (P.proc !== ch) return;
    P.exited = true; P.exitCode = code === null ? sig : code; P.pid = null;
    plog(P, 'manager', 'Process exited (' + P.exitCode + ')');
    if (P._stopping || P.busy) { P.status = 'STOPPED'; return; }
    P.status = 'CRASHED';
    const t = Date.now(); P.restarts = P.restarts.filter(x => t - x < 600000);
    if (P.cfg.autoRestart && P.desired === 'running' && P.restarts.length < 3) {
      P.restarts.push(t); const n = P.restarts.length;
      plog(P, 'manager', 'CRASHED - automatic restart ' + n + '/3 in ' + 2 * n + 's');
      setTimeout(() => { if (P.exited && P.desired === 'running' && !P.busy) startProc(P).then(() => waitReady(P, P.cfg.startupTimeout * 1000)).then(() => { P.status = 'SERVING'; }).catch(e => { P.status = 'CRASHED'; plog(P, 'manager', 'restart failed: ' + e.message); }); }, 2000 * n);
    } else plog(P, 'manager', 'CRASHED - no further automatic restarts');
  });
}
async function stopProc(P) {
  if (P.kind === 'static') { P.status = 'STOPPED'; P.desired = 'stopped'; return; }
  P.desired = 'stopped';
  if (!P.proc || P.exited) { P.status = 'STOPPED'; return; }
  P._stopping = true; P.status = 'STOPPING';
  const g = -P.proc.pid;
  try { process.kill(g, 'SIGCONT'); } catch (e) { } try { process.kill(g, 'SIGTERM'); } catch (e) { }
  const t0 = Date.now(); while (!P.exited && Date.now() - t0 < 8000) await sleep(100);
  if (!P.exited) { try { process.kill(g, 'SIGKILL'); } catch (e) { } const t1 = Date.now(); while (!P.exited && Date.now() - t1 < 2000) await sleep(100); }
  P.status = 'STOPPED';
}
async function waitReady(P, ms) {
  if (P.kind === 'static') return probe(P);
  const t0 = Date.now(); let last = '';
  while (Date.now() - t0 < ms) {
    if (P.exited) throw new Error('Process exited during startup (' + P.exitCode + '): ' + tail(P, 6));
    await sleep(500);
    await adoptPort(P);
    const h = await probe(P); last = h.text;
    if (h.ok) { P.status = 'SERVING'; return h; }
  }
  throw new Error('Did not become healthy within ' + Math.round(ms / 1000) + 's (last check: ' + last + '). Last output: ' + tail(P, 6));
}

/* --------------------------- project analysis / plans -------------------------- */
const SKIP = new Set(['node_modules', '.git', '.venv', '__pycache__', 'vendor', '.gradle', '.idea']);
function listTree(dir) {
  const out = [];
  (function w(d, rel) { let es = []; try { es = fs.readdirSync(d, { withFileTypes: true }); } catch (e) { } for (const e of es) { if (SKIP.has(e.name)) continue; const r = rel ? rel + '/' + e.name : e.name; if (e.isDirectory()) w(path.join(d, e.name), r); else if (e.isFile()) out.push(r); } })(dir, '');
  return out;
}
function makePlan(P, dir, manifest, port) {
  const files = listTree(dir), has = f => files.includes(f);
  const rd = f => { try { return fs.readFileSync(path.join(dir, f), 'utf8').slice(0, 400000); } catch (e) { return ''; } };
  const find1 = n => files.filter(f => baseName(f).toLowerCase() === n.toLowerCase()).sort((a, b) => a.split('/').length - b.split('/').length)[0] || null;
  const findRe = re => files.filter(f => re.test(f)).sort((a, b) => a.split('/').length - b.split('/').length);
  const entry = (manifest.entryPoint || '').replace(/^\/+/, '');
  const custom = manifest.startup && manifest.startup.custom && manifest.startup.command && !/^\s*\(/.test(manifest.startup.command) ? manifest.startup.command.trim() : '';
  let rt = String(manifest.runtime || '');
  let key = /static/i.test(rt) ? 'static' : /type|node/i.test(rt) ? 'node' : /python/i.test(rt) ? 'python' : /java$|^java/i.test(rt) ? 'java' : /^go$/i.test(rt) ? 'go' : /rust/i.test(rt) ? 'rust' : /php/i.test(rt) ? 'php' : /ruby/i.test(rt) ? 'ruby' : /\.net/i.test(rt) ? 'dotnet' : /elixir/i.test(rt) ? 'elixir' : /dart/i.test(rt) ? 'dart' : /deno/i.test(rt) ? 'deno' : /docker/i.test(rt) ? 'docker' : /^c\+\+$|^c$/i.test(rt) ? 'c' : '';
  if (!key) key = find1('package.json') ? 'node' : (find1('requirements.txt') || find1('pyproject.toml') || findRe(/\.py$/).length) ? 'python' : (find1('pom.xml') || find1('build.gradle') || find1('build.gradle.kts') || findRe(/\.java$/).length) ? 'java' : find1('go.mod') ? 'go' : find1('Cargo.toml') ? 'rust' : (find1('composer.json') || findRe(/\.php$/).length) ? 'php' : find1('Gemfile') ? 'ruby' : findRe(/\.(csproj|sln)$/).length ? 'dotnet' : find1('mix.exs') ? 'elixir' : find1('pubspec.yaml') ? 'dart' : find1('deno.json') ? 'deno' : (find1('Dockerfile') || find1('docker-compose.yml') || find1('docker-compose.yaml')) ? 'docker' : findRe(/\.(c|cc|cpp|cxx)$/).length ? 'c' : findRe(/\.html?$/i).length ? 'static' : '';
  if (!key) throw new HttpError(400, 'Cannot detect a runtime for this project (no manifest, source or index.html found)');
  const plan = { key, cwd: '', steps: [], need: [], start: '', env: {}, docroot: '' };
  const NEED_MSG = t => 'The runtime "' + t + '" is not installed on the Server Manager machine. Install it there (or use the Docker image, which includes the common runtimes) and deploy again.';
  const mode = P.cfg.mode === 'PRODUCTION';

  if (key === 'static') {
    const idx = findRe(/(^|\/)index\.html?$/i)[0] || findRe(/\.html?$/i)[0];
    if (!idx) throw new HttpError(400, 'No HTML file found for a static site');
    plan.kind = 'static'; plan.docroot = dirOf(idx); return finish();
  }
  if (key === 'node') {
    const pj = find1('package.json'); const app = dirOf(pj || ''); plan.cwd = app; let pkg = {};
    try { pkg = JSON.parse(rd(pj)); } catch (e) { }
    const sc = pkg.scripts || {}, lock = f => has(jn(app, f));
    const tool = lock('pnpm-lock.yaml') && hasCmd('pnpm') ? 'pnpm' : lock('yarn.lock') && hasCmd('yarn') ? 'yarn' : 'npm';
    plan.need = ['node', tool === 'npm' ? 'npm' : tool];
    if (pj) plan.steps.push({ label: 'Install dependencies', cmd: tool === 'npm' ? 'npm install --no-audit --no-fund --loglevel=error' : tool + ' install', cwd: app });
    if (sc.build) plan.steps.push({ label: 'Build', cmd: tool === 'npm' ? 'npm run build' : tool + ' run build', cwd: app });
    const rel = f => (f || '').startsWith(app + '/') ? f.slice(app.length + 1) : f;
    const mainF = pkg.main && has(jn(app, pkg.main)) ? pkg.main : '';
    const ent = [rel(entry), 'server.js', 'app.js', 'index.js', 'main.js', 'server.mjs', 'index.mjs', 'src/server.js', 'src/index.js', 'src/app.js'].find(f => f && /\.(js|mjs|cjs)$/.test(f) && has(jn(app, f)));
    const tsEnt = ['server.ts', 'app.ts', 'index.ts', 'main.ts', 'src/server.ts', 'src/index.ts', 'src/app.ts'].find(f => has(jn(app, f)));
    if (custom) plan.start = custom;
    else if (sc.start) plan.start = tool === 'npm' ? 'npm start' : tool + ' start';
    else if (mainF) plan.start = 'node ' + q(mainF);
    else if (ent) plan.start = 'node ' + q(ent);
    else if (tsEnt) plan.start = 'npx --yes tsx ' + q(tsEnt);
    else {
      const out = ['dist', 'build', 'out', 'public', '.'].find(d => has(jn(app, d, 'index.html')));
      if (out !== undefined) { plan.kind = 'static'; plan.docroot = jn(app, out === '.' ? '' : out); return finish(); }
      throw new HttpError(400, 'No start script, main file or server entry found in this Node.js project');
    }
    return finish();
  }
  if (key === 'python') {
    const reqF = find1('requirements.txt'), pyp = find1('pyproject.toml'), mng = find1('manage.py');
    const app = dirOf(reqF || pyp || mng || entry || ''); plan.cwd = app; plan.need = ['python3'];
    const pys = files.filter(f => f.endsWith('.py') && (!app || f.startsWith(app + '/'))).slice(0, 150);
    const all = pys.map(f => rd(f)).join('\n'), rq = (rd(reqF || '') || '').toLowerCase();
    const isFast = /\bFastAPI\s*\(/.test(all), isFlask = /\bFlask\s*\(/.test(all), isDjango = !!mng;
    plan.steps.push({ label: 'Create virtual environment', cmd: 'python3 -m venv .venv', cwd: app });
    if (reqF) plan.steps.push({ label: 'Install requirements', cmd: '.venv/bin/pip install --no-input -r ' + q(baseName(reqF)), cwd: app });
    else if (pyp) plan.steps.push({ label: 'Install project', cmd: '.venv/bin/pip install --no-input .', cwd: app });
    const extra = []; if (isFast && !/fastapi/.test(rq)) extra.push('fastapi'); if (isFast && !/uvicorn/.test(rq)) extra.push('uvicorn'); if (isFlask && !/flask/.test(rq)) extra.push('flask'); if (isDjango && !/django/.test(rq)) extra.push('django');
    if (extra.length) plan.steps.push({ label: 'Install ' + extra.join(', '), cmd: '.venv/bin/pip install --no-input ' + extra.join(' '), cwd: app });
    const rel = f => (f || '').startsWith(app + '/') ? f.slice(app.length + 1) : f;
    let ent = [rel(entry), 'app.py', 'main.py', 'server.py', 'run.py', 'wsgi.py', 'index.py', 'manage.py'].find(f => f && f.endsWith('.py') && has(jn(app, f)));
    if (!ent) ent = rel(pys.find(f => /\b(FastAPI|Flask)\s*\(/.test(rd(f))) || pys[0] || '');
    if (!ent) throw new HttpError(400, 'No Python entry file found');
    const mod = ent.replace(/\.py$/, '').replace(/\//g, '.'), src = rd(jn(app, ent));
    if (custom) plan.start = custom.replace(/^python3?\b/, '.venv/bin/python');
    else if (isDjango) plan.start = '.venv/bin/python manage.py runserver ' + BIND_CHILD + ':PORT --noreload';
    else if (isFast) plan.start = '.venv/bin/python -m uvicorn ' + mod + ':' + ((src.match(/(\w+)\s*(?::\s*\w+\s*)?=\s*FastAPI\s*\(/) || [])[1] || 'app') + ' --host ' + BIND_CHILD + ' --port PORT';
    else if (isFlask && !/\.run\s*\(/.test(src)) plan.start = '.venv/bin/python -m flask --app ' + mod + ':' + ((src.match(/(\w+)\s*=\s*Flask\s*\(/) || [])[1] || 'app') + ' run --host ' + BIND_CHILD + ' --port PORT';
    else plan.start = '.venv/bin/python ' + q(ent);
    return finish();
  }
  if (key === 'java') {
    const pom = find1('pom.xml'), gr = find1('build.gradle') || find1('build.gradle.kts');
    plan.need = ['java'];
    const jarOf = (app, sub, bad) => { let best = null, size = 0; const d = path.join(dir, app, sub); try { for (const f of fs.readdirSync(d)) { if (!f.endsWith('.jar') || bad.test(f)) continue; const s = fs.statSync(path.join(d, f)).size; if (s > size) { size = s; best = f; } } } catch (e) { } return best ? jn(sub, best) : null; };
    if (pom) {
      const app = dirOf(pom); plan.cwd = app; const w = has(jn(app, 'mvnw'));
      plan.steps.push({ label: 'Build (Maven)', cmd: (w ? 'chmod +x mvnw && ./mvnw' : 'mvn') + ' -q -B -DskipTests package', cwd: app }); if (!w) plan.need.push('mvn');
      plan.finalize = () => { const j = jarOf(app, 'target', /-(sources|javadoc)\.jar$|^original-/); if (!j) throw new Error('Maven build produced no runnable .jar in target/'); return 'java -jar ' + q(j) + ' --server.port=PORT'; };
    } else if (gr) {
      const app = dirOf(gr); plan.cwd = app; const w = has(jn(app, 'gradlew'));
      plan.steps.push({ label: 'Build (Gradle)', cmd: (w ? 'chmod +x gradlew && ./gradlew' : 'gradle') + ' build -x test --no-daemon -q', cwd: app }); if (!w) plan.need.push('gradle');
      plan.finalize = () => { const j = jarOf(app, 'build/libs', /-(plain|sources|javadoc)\.jar$/); if (!j) throw new Error('Gradle build produced no runnable .jar in build/libs/'); return 'java -jar ' + q(j) + ' --server.port=PORT'; };
    } else {
      const js = findRe(/\.java$/); if (!js.length) throw new HttpError(400, 'No Java sources found');
      plan.need.push('javac');
      plan.steps.push({ label: 'Compile (javac)', cmd: "mkdir -p out && javac -d out $(find . -name '*.java')", cwd: '' });
      const mainFile = js.find(f => /public\s+static\s+void\s+main\s*\(/.test(rd(f))) || js[0];
      const pk = (rd(mainFile).match(/^\s*package\s+([\w.]+)\s*;/m) || [])[1];
      plan.start = 'java -cp out ' + (pk ? pk + '.' : '') + baseName(mainFile).replace(/\.java$/, '');
    }
    if (custom) { plan.start = custom; delete plan.finalize; }
    return finish();
  }
  if (key === 'go') {
    const gm = find1('go.mod'), app = dirOf(gm || ''); plan.cwd = app; plan.need = ['go'];
    const mains = files.filter(f => f.endsWith('.go') && (!app || f.startsWith(app + '/')) && /^\s*package\s+main\b/m.test(rd(f)) && /func\s+main\s*\(/.test(rd(f))).sort((a, b) => a.split('/').length - b.split('/').length);
    if (!mains.length) throw new HttpError(400, 'No Go "package main" with func main() found');
    const md = dirOf(mains[0]), relDir = md === app ? '.' : './' + (app ? md.slice(app.length + 1) : md);
    plan.steps.push({ label: 'Build (go build)', cmd: 'go build -o app_bin ' + q(relDir), cwd: app });
    plan.start = custom || './app_bin'; return finish();
  }
  if (key === 'rust') {
    const ct = find1('Cargo.toml'), app = dirOf(ct || ''); plan.cwd = app; plan.need = ['cargo'];
    const name = (rd(ct).match(/\[package\][^[]*?\bname\s*=\s*"([^"]+)"/s) || [])[1];
    if (!name) throw new HttpError(400, 'Cannot read the package name from Cargo.toml');
    plan.steps.push({ label: 'Build (cargo --release)', cmd: 'cargo build --release', cwd: app });
    plan.start = custom || './target/release/' + name; return finish();
  }
  if (key === 'php') {
    const cj = find1('composer.json'), art = find1('artisan'), app = dirOf(cj || art || findRe(/\.php$/)[0] || ''); plan.cwd = app; plan.need = ['php'];
    if (cj) { plan.steps.push({ label: 'Install dependencies (composer)', cmd: 'composer install --no-dev --no-interaction --no-progress', cwd: app }); plan.need.push('composer'); }
    if (art) {
      if (!has(jn(app, '.env')) && has(jn(app, '.env.example'))) plan.steps.push({ label: 'Create .env', cmd: 'cp .env.example .env && php artisan key:generate --force', cwd: app });
      plan.start = custom || 'php artisan serve --host=' + BIND_CHILD + ' --port=PORT';
    } else {
      const docroot = has(jn(app, 'public/index.php')) ? 'public' : '.';
      plan.start = custom || 'php -S ' + BIND_CHILD + ':PORT -t ' + q(docroot);
    }
    return finish();
  }
  if (key === 'ruby') {
    const gf = find1('Gemfile'), app = dirOf(gf || findRe(/\.rb$/)[0] || ''); plan.cwd = app; plan.need = ['ruby'];
    if (gf) { plan.steps.push({ label: 'Install gems (bundle)', cmd: 'bundle install', cwd: app }); plan.need.push('bundle'); }
    const b = gf ? 'bundle exec ' : '';
    if (has(jn(app, 'bin/rails')) || has(jn(app, 'config/application.rb'))) plan.start = b + 'rails server -b ' + BIND_CHILD + ' -p PORT';
    else if (has(jn(app, 'config.ru'))) plan.start = b + 'rackup -o ' + BIND_CHILD + ' -p PORT';
    else { const e = ['app.rb', 'server.rb', 'main.rb', 'index.rb'].find(f => has(jn(app, f))) || baseName(findRe(/\.rb$/)[0] || 'app.rb'); plan.start = b + 'ruby ' + q(e); }
    if (custom) plan.start = custom; return finish();
  }
  if (key === 'dotnet') {
    const pr = findRe(/\.csproj$/)[0], app = dirOf(pr || ''); plan.cwd = app; plan.need = ['dotnet'];
    plan.steps.push({ label: 'Build (dotnet)', cmd: 'dotnet build -c Release', cwd: app });
    plan.start = custom || 'dotnet run -c Release --no-build --urls http://' + BIND_CHILD + ':PORT'; return finish();
  }
  if (key === 'elixir') {
    const mx = find1('mix.exs'), app = dirOf(mx || ''); plan.cwd = app; plan.need = ['mix'];
    plan.steps.push({ label: 'Fetch deps', cmd: 'mix local.hex --force && mix local.rebar --force && mix deps.get && mix compile', cwd: app });
    plan.env.MIX_ENV = mode ? 'prod' : 'dev';
    plan.start = custom || (/phoenix/.test(rd(mx)) ? 'mix phx.server' : 'mix run --no-halt'); return finish();
  }
  if (key === 'dart') {
    const ps = find1('pubspec.yaml'), app = dirOf(ps || ''); plan.cwd = app; plan.need = ['dart'];
    plan.steps.push({ label: 'Fetch packages', cmd: 'dart pub get', cwd: app }); plan.start = custom || 'dart run'; return finish();
  }
  if (key === 'deno') {
    const dj = find1('deno.json'), app = dirOf(dj || ''); plan.cwd = app; plan.need = ['deno'];
    let tasks = {}; try { tasks = JSON.parse(rd(dj)).tasks || {}; } catch (e) { }
    const e = (entry.startsWith(app + '/') ? entry.slice(app.length + 1) : entry) || ['main.ts', 'server.ts', 'app.ts', 'mod.ts'].find(f => has(jn(app, f))) || 'main.ts';
    plan.start = custom || (tasks.start ? 'deno task start' : 'deno run -A ' + q(e)); return finish();
  }
  if (key === 'docker') {
    const dc = find1('docker-compose.yml') || find1('docker-compose.yaml') || find1('compose.yaml'), df = find1('Dockerfile'); plan.need = ['docker'];
    const app = dirOf(dc || df || ''); plan.cwd = app;
    plan.start = custom || (dc ? 'docker compose up --build' : 'docker build -t mboya-' + P.id.toLowerCase().slice(0, 40) + ' . && docker run --rm -p PORT:PORT -e PORT=PORT mboya-' + P.id.toLowerCase().slice(0, 40));
    return finish();
  }
  if (key === 'c') {
    const cpp = findRe(/\.(cc|cpp|cxx)$/).length > 0, mk = find1('Makefile') || find1('makefile'), app = dirOf(mk || ''); plan.cwd = app; plan.need = mk ? ['make'] : [cpp ? 'g++' : 'gcc'];
    if (mk) {
      plan.steps.push({ label: 'Build (make)', cmd: 'make', cwd: app });
      plan.finalize = () => { let best = null, bt = 0; for (const f of listTree(path.join(dir, app))) { try { const st = fs.statSync(path.join(dir, app, f)); if ((st.mode & 0o111) && st.isFile() && !/\.(sh|py|pl|rb)$/.test(f) && !f.includes('/.') && st.mtimeMs >= bt) { best = f; bt = st.mtimeMs; } } catch (e) { } } if (!best) throw new Error('make produced no executable'); return './' + best; };
    } else {
      plan.steps.push({ label: 'Compile', cmd: (cpp ? "g++ -O2 -o app_bin $(find . -name '*.cc' -o -name '*.cpp' -o -name '*.cxx')" : "gcc -O2 -o app_bin $(find . -name '*.c')"), cwd: '' });
      plan.start = './app_bin';
    }
    if (custom) { plan.start = custom; delete plan.finalize; } return finish();
  }
  throw new HttpError(400, 'Unsupported runtime: ' + key);

  function finish() {
    for (const t of plan.need) if (!hasCmd(t)) throw new HttpError(422, NEED_MSG(t));
    plan.kind = plan.kind || 'process';
    plan.guess = manifest.startup && manifest.startup.command || '';
    return plan;
  }
}

/* --------------------------------- deployment --------------------------------- */
function writeFiles(dir, fl) {
  fs.mkdirSync(dir, { recursive: true });
  const norm = fl.map(f => ({ p: String(f.path || '').replace(/\\/g, '/').replace(/^\/+|^\.\//, ''), b64: f.b64 })).filter(f => f.p && !/(^|\/)(__MACOSX|\.git|node_modules)\//.test(f.p) && !/(^|\/)\.DS_Store$/.test(f.p));
  const firsts = new Set(norm.map(f => f.p.split('/')[0]));
  const root = norm.length && norm.every(f => f.p.includes('/')) && firsts.size === 1 ? [...firsts][0] + '/' : '';
  for (const f of norm) {
    const rel = root ? f.p.slice(root.length) : f.p; if (!rel) continue;
    const full = path.resolve(dir, rel);
    if (full !== dir && !full.startsWith(dir + path.sep)) throw new HttpError(400, 'Rejected unsafe file path: ' + f.p);
    fs.mkdirSync(path.dirname(full), { recursive: true });
    const buf = Buffer.from(f.b64 || '', 'base64'); fs.writeFileSync(full, buf, { mode: buf[0] === 0x23 && buf[1] === 0x21 ? 0o755 : 0o644 });
  }
  return root;
}
async function deploy(body, req) {
  const m = body.manifest || {}, files = body.files;
  if (!Array.isArray(files) || !files.length) throw new HttpError(400, 'No project files were uploaded');
  let id = String(m.projectId || m.name || '').replace(/[^A-Za-z0-9_-]/g, '');
  if (!id) id = crypto.randomBytes(6).toString('hex'); id = id.slice(0, 64);
  let P = projects.get(id); const isNew = !P;
  if (isNew) { P = newProject(id, m.name || id); projects.set(id, P); fs.mkdirSync(projDir(id), { recursive: true }); }
  if (P.busy) throw new HttpError(409, 'DEPLOYMENT IN PROGRESS for this project');
  P.busy = true; P.name = m.name || P.name;
  if (m.environment) P.cfg.mode = /prod/i.test(m.environment) ? 'PRODUCTION' : 'DEVELOPMENT';
  if (m.healthEndpoint) P.cfg.healthPath = m.healthEndpoint;
  const maxV = Math.max(0, ...P.versions.map(x => x.v)); let v = +m.version || maxV + 1; if (P.versions.some(x => x.v === v)) v = maxV + 1;
  const rec = { v, t: isoNow(), runtime: m.runtime || '', status: 'DEPLOYING', reason: '' }; P.versions.push(rec);
  const dir = verDir(id, v); const prev = { version: P.version, plan: P.plan, kind: P.kind, runtime: P.runtime, wasRunning: !!(P.proc && !P.exited) || (P.kind === 'static' && P.status === 'SERVING') };
  plog(P, 'manager', '=== Deployment v' + v + ' started (' + (m.runtime || 'auto') + ') ===');
  try {
    P.status = 'PREPARING'; const root = writeFiles(dir, files);
    const m2 = Object.assign({}, m, { entryPoint: root && String(m.entryPoint || '').startsWith(root) ? String(m.entryPoint).slice(root.length) : m.entryPoint });
    P.status = 'ANALYZING'; const plan = makePlan(P, dir, m2, P.port);
    for (const s of plan.steps) { P.status = 'PREPARING'; await runStep(P, s.label, s.cmd, path.join(dir, s.cwd || ''), Object.assign({}, procEnv(Object.assign({}, P, { port: P.port || 0 })), plan.env, { NODE_ENV: 'development' })); }
    if (plan.finalize) plan.start = plan.finalize(); delete plan.finalize;
    delete plan.steps; delete plan.need; rec.plan = JSON.parse(JSON.stringify(plan));
    if (!plan.start && plan.kind !== 'static') throw new Error('No start command could be determined');
    const wantPort = +m.port || null;
    if (wantPort) { if ([...projects.values()].some(p => p !== P && p.port === wantPort)) throw new HttpError(409, 'Port ' + wantPort + ' is used by another project'); P.port = wantPort; }
    else if (!P.port && plan.kind !== 'static') P.port = await freePort();
    // switch over: stop the old version, start the new one
    P.status = 'STARTING'; await stopProc(P);
    P.plan = plan; P.kind = plan.kind || 'process'; P.runtime = m.runtime || plan.key; P.version = v; P.guess = plan.guess;
    P.cfg.startCommand = plan.guess || plan.start; P.cfg.customCommand = !!(m.startup && m.startup.custom);
    P.env = P.env || {};
    P.busy = false; await startProc(P); P.busy = true;
    const h = await waitReady(P, Math.max(10, +P.cfg.startupTimeout || 60) * 1000);
    rec.status = 'SERVING'; rec.port = P.port; P.versions.forEach(x => { if (x !== rec && x.status === 'SERVING') x.status = 'SUPERSEDED'; });
    P.deployedAt = isoNow(); P.desired = 'running'; plog(P, 'manager', '=== Deployment v' + v + ' SERVING (' + h.text + ') ===');
    // prune old version directories
    const keep = P.versions.filter(x => x.status === 'SERVING' || x.status === 'SUPERSEDED').map(x => x.v).sort((a, b) => b - a).slice(0, KEEP_VERSIONS);
    for (const x of P.versions) if (!keep.includes(x.v) && x.v !== v) { try { fs.rmSync(verDir(id, x.v), { recursive: true, force: true }); } catch (e) { } x.pruned = true; }
    P.busy = false; save();
    return urlInfo(P, req);
  } catch (e) {
    rec.status = 'FAILED'; rec.reason = e.message || String(e); plog(P, 'manager', 'Deployment v' + v + ' FAILED: ' + rec.reason);
    P.busy = true; try { await stopProc(P); } catch (x) { }
    try { fs.rmSync(dir, { recursive: true, force: true }); } catch (x) { }
    // restore previous version
    if (prev.version && prev.plan) {
      P.plan = prev.plan; P.kind = prev.kind; P.runtime = prev.runtime; P.version = prev.version;
      if (prev.wasRunning) { try { P.busy = false; await startProc(P); await waitReady(P, 30000); plog(P, 'manager', 'Previous version v' + prev.version + ' restored'); rec.rollback = 'Kept v' + prev.version + ' serving'; } catch (x) { P.status = 'FAILED'; plog(P, 'manager', 'Could not restore previous version: ' + x.message); } }
      else P.status = 'STOPPED';
    } else { P.status = 'FAILED'; if (isNew) { P.port = null; } }
    P.busy = false;
    if (isNew && !prev.version && e instanceof HttpError && e.status < 500) { projects.delete(id); try { fs.rmSync(projDir(id), { recursive: true, force: true }); } catch (x) { } }
    save();
    throw e instanceof HttpError ? e : new HttpError(500, rec.reason);
  }
}
async function rollback(P, v) {
  const rec = P.versions.find(x => x.v === v);
  if (!rec || rec.pruned || !fs.existsSync(verDir(P.id, v))) throw new HttpError(404, 'Version v' + v + ' is no longer available on the manager');
  if (P.busy) throw new HttpError(409, 'DEPLOYMENT IN PROGRESS for this project');
  P.busy = true;
  try {
    await stopProc(P);
    const plan = rec.plan; if (!plan) throw new HttpError(404, 'Version v' + v + ' has no saved start plan');
    P.plan = JSON.parse(JSON.stringify(plan)); P.kind = plan.kind || 'process'; P.runtime = rec.runtime || P.runtime; P.version = v; P.busy = false; await startProc(P); P.busy = true; await waitReady(P, P.cfg.startupTimeout * 1000);
    P.versions.forEach(x => { if (x.status === 'SERVING') x.status = 'SUPERSEDED'; }); rec.status = 'SERVING'; P.desired = 'running';
    plog(P, 'manager', 'Rolled back to v' + v);
  } finally { P.busy = false; save(); }
}

/* ------------------------------------ metrics ------------------------------------ */
let psCache = { t: 0, map: new Map() };
function psSnap() {
  if (Date.now() - psCache.t < 3000) return psCache.map;
  const map = new Map();
  try { cp.execSync('ps -eo pgid=,pcpu=,rss=', { encoding: 'utf8' }).split('\n').forEach(l => { const c = l.trim().split(/\s+/); if (c.length < 3) return; const g = +c[0], o = map.get(g) || { cpu: 0, rss: 0, n: 0 }; o.cpu += parseFloat(c[1]) || 0; o.rss += parseInt(c[2]) || 0; o.n++; map.set(g, o); }); } catch (e) { }
  psCache = { t: Date.now(), map }; return map;
}
function usage(P) { const u = P.pid ? psSnap().get(P.pid) : null; return { cpu: u ? u.cpu.toFixed(1) + '%' : '—', ram: u ? (u.rss / 1024).toFixed(1) + ' MB' : '—', procs: u ? u.n : 0 }; }

/* ------------------------------------ HTTP ------------------------------------ */
function baseUrl(req) {
  if (PUBLIC_URL) return PUBLIC_URL;
  const proto = (req.headers['x-forwarded-proto'] || (req.socket.encrypted ? 'https' : 'http')).split(',')[0].trim();
  return proto + '://' + (req.headers['x-forwarded-host'] || req.headers.host || ('localhost:' + PORT)).split(',')[0].trim();
}
function urlOf(P, req) {
  if (URL_MODE === 'port' && P.port) { const h = new URL(baseUrl(req)).hostname; return (req.headers['x-forwarded-proto'] || 'http') + '://' + h + ':' + P.port; }
  return baseUrl(req) + '/p/' + P.id;
}
function urlInfo(P, req) { return { id: P.id, port: P.port, url: urlOf(P, req), pid: P.pid, version: P.version, status: P.status }; }
function item(P, req) {
  const u = usage(P);
  return { id: P.id, name: P.name, status: P.status, port: P.port, url: urlOf(P, req), pid: P.pid, runtime: P.runtime, version: P.version, uptime: P.proc && !P.exited || (P.kind === 'static' && P.status === 'SERVING') ? fmtUp(Date.now() - P.startedAt) : '—', cpu: u.cpu, ram: u.ram, kind: P.kind, private: !!P.cfg.private };
}
function corsHeaders(req, extra) {
  const h = { 'access-control-allow-origin': CORS_ORIGIN, 'access-control-allow-methods': 'GET,POST,PUT,PATCH,DELETE,HEAD,OPTIONS', 'access-control-allow-headers': req.headers['access-control-request-headers'] || 'Authorization,Content-Type', 'access-control-max-age': '86400', 'access-control-expose-headers': '*', vary: 'Origin' };
  if (req.headers['access-control-request-private-network']) h['access-control-allow-private-network'] = 'true';
  return Object.assign(h, extra || {});
}
function send(req, res, code, obj, extra) {
  const body = typeof obj === 'string' ? obj : JSON.stringify(obj);
  res.writeHead(code, corsHeaders(req, Object.assign({ 'content-type': typeof obj === 'string' ? 'text/plain; charset=utf-8' : 'application/json', 'cache-control': 'no-store' }, extra)));
  res.end(req.method === 'HEAD' ? undefined : body);
}
const fails = new Map();
function authed(req) {
  const ip = req.socket.remoteAddress, f = fails.get(ip);
  if (f && f.n >= 10 && Date.now() - f.t < 60000) return 429;
  const m = /^Bearer\s+(.+)$/i.exec(req.headers.authorization || '');
  const ok = m && crypto.timingSafeEqual(crypto.createHash('sha256').update(m[1].trim()).digest(), TOKEN_HASH);
  if (ok) { fails.delete(ip); return 200; }
  fails.set(ip, { n: (f && Date.now() - f.t < 60000 ? f.n : 0) + 1, t: Date.now() }); return 401;
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    const ch = []; let n = 0;
    req.on('data', d => { n += d.length; if (n > MAX_UPLOAD) { reject(new HttpError(413, 'Upload larger than ' + Math.round(MAX_UPLOAD / 1048576) + ' MB (raise MAX_UPLOAD_MB)')); req.destroy(); } else ch.push(d); });
    req.on('end', () => { if (!n) return resolve({}); try { resolve(JSON.parse(Buffer.concat(ch).toString('utf8'))); } catch (e) { reject(new HttpError(400, 'Invalid JSON body')); } });
    req.on('error', reject);
  });
}
function serveStatic(P, req, res, sub) {
  const root = path.resolve(verDir(P.id, P.version), P.plan.docroot || '');
  let rel = decodeURIComponent((sub || '/').split('?')[0]); let full = path.resolve(root, '.' + rel);
  if (full !== root && !full.startsWith(root + path.sep)) return send(req, res, 403, { error: 'Forbidden' });
  try { if (fs.statSync(full).isDirectory()) full = path.join(full, 'index.html'); } catch (e) { }
  if (!fs.existsSync(full) && !/\.\w{1,6}$/.test(rel)) full = path.join(root, 'index.html');
  fs.readFile(full, (err, data) => {
    if (err) return send(req, res, 404, 'Not found');
    res.writeHead(200, corsHeaders(req, { 'content-type': MIME[path.extname(full).slice(1).toLowerCase()] || 'application/octet-stream', 'cache-control': 'no-cache' }));
    res.end(req.method === 'HEAD' ? undefined : data);
  });
}
function proxy(P, req, res, sub) {
  if (P.kind === 'static') return P.status === 'SERVING' ? serveStatic(P, req, res, sub) : send(req, res, 503, { error: 'Project is not running', status: P.status });
  if (!P.proc || P.exited || !P.port || P.status === 'PAUSED') return send(req, res, 503, { error: 'Project is not running', status: P.status });
  const prefix = '/p/' + P.id;
  const headers = Object.assign({}, req.headers, { host: '127.0.0.1:' + P.port, 'x-forwarded-for': (req.headers['x-forwarded-for'] ? req.headers['x-forwarded-for'] + ', ' : '') + req.socket.remoteAddress, 'x-forwarded-host': req.headers.host || '', 'x-forwarded-proto': (req.headers['x-forwarded-proto'] || (req.socket.encrypted ? 'https' : 'http')), 'x-forwarded-prefix': prefix });
  const up = http.request({ host: '127.0.0.1', port: P.port, path: sub || '/', method: req.method, headers }, ur => {
    const h = Object.assign({}, ur.headers);
    if (h.location && h.location.startsWith('/') && !h.location.startsWith('//') && URL_MODE !== 'port') h.location = prefix + h.location;
    if (CORS_ORIGIN && !h['access-control-allow-origin']) Object.assign(h, corsHeaders(req));
    res.writeHead(ur.statusCode, ur.statusMessage, h); ur.pipe(res);
  });
  up.on('error', e => { if (!res.headersSent) send(req, res, 502, { error: 'Bad gateway: ' + e.message }); else res.destroy(); });
  req.pipe(up);
}
function findProjectFromReferer(req) { const m = /\/p\/([A-Za-z0-9_-]+)(?:\/|$|\?)/.exec(req.headers.referer || ''); return m ? projects.get(m[1]) : null; }
function appPage() {
  for (const f of [path.join(__dirname, 'public', 'index.html'), path.join(__dirname, 'index.html')]) if (fs.existsSync(f)) return fs.readFileSync(f);
  return Buffer.from('<!doctype html><meta name=viewport content="width=device-width,initial-scale=1"><body style="font-family:system-ui;background:#0a1a3f;color:#fff;padding:24px"><h2>MBOYA Server Manager is running</h2><p>Version ' + VERSION + '. Open MBOYA Server Runner, go to Settings &rarr; Server Manager and enter this address plus your access token.</p></body>');
}
let runtimesCache = null;
async function runtimes() {
  if (runtimesCache) return runtimesCache;
  const defs = { node: 'node -v', npm: 'npm -v', python3: 'python3 -V', java: 'java -version', mvn: 'mvn -v', gradle: 'gradle -v', go: 'go version', cargo: 'cargo -V', php: 'php -v', composer: 'composer -V', ruby: 'ruby -v', bundle: 'bundle -v', dotnet: 'dotnet --version', mix: 'mix -v', dart: 'dart --version', deno: 'deno -V', gcc: 'gcc --version', make: 'make -v', docker: 'docker -v' };
  const out = {};
  await Promise.all(Object.entries(defs).map(([k, c]) => new Promise(r => { if (!hasCmd(c.split(' ')[0])) { out[k] = null; return r(); } cp.exec(c, { timeout: 8000 }, (e, so, se) => { out[k] = ((so || '') + (se || '')).split('\n').map(x => x.trim()).filter(x => x && !/^Picked up/.test(x))[0] || 'installed'; r(); }); })));
  return runtimesCache = out;
}

async function handle(req, res) {
  const u = new URL(req.url, 'http://x'), p = u.pathname;
  if (req.method === 'OPTIONS') { res.writeHead(204, corsHeaders(req)); return res.end(); }
  // ---- reverse proxy to deployed projects (public unless the project is marked private) ----
  let m = /^\/p\/([A-Za-z0-9_-]+)(\/.*)?$/.exec(p);
  if (m) {
    const P = projects.get(m[1]); if (!P) return send(req, res, 404, { error: 'No such project' });
    if (!m[2]) { res.writeHead(302, { location: '/p/' + P.id + '/' + u.search }); return res.end(); }
    if (P.cfg.private && authed(req) !== 200) return send(req, res, 401, { error: 'This project is private' });
    return proxy(P, req, res, m[2] + u.search);
  }
  if (p === '/ping') return send(req, res, 200, { mboya: true, manager: true, version: VERSION, auth: true, platform: process.platform, time: isoNow() });
  if ((p === '/' || p === '/index.html' || p === '/app') && (req.method === 'GET' || req.method === 'HEAD')) { res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-cache' }); return res.end(appPage()); }
  if (/^\/servers(\/|$)|^\/runtimes$|^\/info$/.test(p)) {
    const a = authed(req); if (a !== 200) return send(req, res, a, { error: a === 429 ? 'Too many failed attempts - wait a minute' : 'Unauthorized: missing or wrong access token' });
    return api(req, res, u, p);
  }
  // absolute-path assets requested by a proxied page (e.g. /static/app.js) -> follow the Referer
  const rp = findProjectFromReferer(req); if (rp) return proxy(rp, req, res, p + u.search);
  return send(req, res, 404, { error: 'Not found' });
}
async function api(req, res, u, p) {
  try {
    if (p === '/runtimes' || p === '/info') return send(req, res, 200, { version: VERSION, platform: process.platform + '/' + process.arch, hostname: os.hostname(), urlMode: URL_MODE, publicUrl: PUBLIC_URL || null, runtimes: await runtimes(), projects: projects.size });
    if (p === '/servers' && req.method === 'GET') return send(req, res, 200, [...projects.values()].map(P => item(P, req)));
    if (p === '/servers' && req.method === 'POST') { const body = await readBody(req); return send(req, res, 200, await deploy(body, req)); }
    const m = /^\/servers\/([A-Za-z0-9_-]+)(?:\/(\w+))?$/.exec(p); if (!m) throw new HttpError(404, 'Not found');
    const P = projects.get(m[1]); if (!P) throw new HttpError(404, 'No such project: ' + m[1]); const act = m[2] || '';
    if (!act && req.method === 'GET') return send(req, res, 200, Object.assign(item(P, req), { cfg: P.cfg, versions: P.versions, plan: P.plan && { start: P.plan.start, cwd: P.plan.cwd }, env: Object.keys(P.env).concat(Object.keys(SECRETS[P.id] || {})) }));
    if (!act && req.method === 'DELETE') {
      P.busy = true; await stopProc(P); projects.delete(P.id); delete SECRETS[P.id]; saveSecrets();
      try { fs.rmSync(projDir(P.id), { recursive: true, force: true }); } catch (e) { } save(); return send(req, res, 200, { ok: true });
    }
    if (act === 'health') { const h = await probe(P); return send(req, res, 200, { ok: h.ok, status: h.text, ms: h.ms }); }
    if (act === 'logs') { const n = Math.min(+u.searchParams.get('limit') || 500, 3000); return send(req, res, 200, { logs: P.logs.slice(-n) }); }
    if (act === 'metrics') { const us = usage(P); return send(req, res, 200, { status: P.status, version: P.version, pid: P.pid || '—', port: P.port || '—', cpu: us.cpu, ram: us.ram, processes: us.procs, uptime: P.proc && !P.exited ? fmtUp(Date.now() - P.startedAt) : '—', restarts_10min: P.restarts.length, host: os.hostname(), load: os.loadavg().map(x => x.toFixed(2)).join(' / '), system_ram_free: (os.freemem() / 1048576).toFixed(0) + ' MB' }); }
    if (act === 'env' && req.method === 'PUT') {
      const b = await readBody(req); if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(b.name || '')) throw new HttpError(400, 'Invalid variable name');
      if (b.secret) { (SECRETS[P.id] = SECRETS[P.id] || {})[b.name] = enc(b.value == null ? '' : b.value); saveSecrets(); delete P.env[b.name]; } else { P.env[b.name] = String(b.value == null ? '' : b.value); if (SECRETS[P.id]) { delete SECRETS[P.id][b.name]; saveSecrets(); } }
      save(); plog(P, 'manager', 'Environment variable ' + b.name + ' set' + (b.secret ? ' (encrypted)' : '')); return send(req, res, 200, { ok: true, restartRequired: !!(P.proc && !P.exited) });
    }
    if (act === 'config' && req.method === 'PUT') {
      const b = await readBody(req), c = P.cfg;
      if (b.autoRestart != null) c.autoRestart = !!b.autoRestart; if (b.mode) c.mode = /prod/i.test(b.mode) ? 'PRODUCTION' : 'DEVELOPMENT';
      if (typeof b.healthPath === 'string') c.healthPath = b.healthPath.startsWith('/') ? b.healthPath : '/' + b.healthPath; if (+b.retries) c.retries = +b.retries; if (+b.startupTimeout) c.startupTimeout = +b.startupTimeout;
      if (b.private != null) c.private = !!b.private;
      if (typeof b.startCommand === 'string' && b.startCommand.trim() && b.startCommand.trim() !== c.startCommand && b.startCommand.trim() !== P.guess && P.plan) { P.plan.start = b.startCommand.trim(); c.startCommand = P.plan.start; c.customCommand = true; plog(P, 'manager', 'Custom start command set: ' + P.plan.start); }
      save(); return send(req, res, 200, { ok: true, config: c });
    }
    if (req.method !== 'POST') throw new HttpError(405, 'Method not allowed');
    if (act === 'rollback') { const b = await readBody(req); await rollback(P, +b.version); return send(req, res, 200, { ok: true, status: P.status }); }
    if (['start', 'stop', 'restart', 'pause', 'resume'].includes(act)) {
      if (P.busy) throw new HttpError(409, 'DEPLOYMENT IN PROGRESS for this project');
      P.busy = true;
      try {
        if (act === 'stop') await stopProc(P);
        else if (act === 'pause') { if (P.kind === 'static') throw new HttpError(400, 'Static sites cannot be paused'); if (!P.proc || P.exited) throw new HttpError(409, 'Project is not running'); process.kill(-P.proc.pid, 'SIGSTOP'); P.status = 'PAUSED'; plog(P, 'manager', 'Paused'); }
        else if (act === 'resume') { if (P.status !== 'PAUSED') throw new HttpError(409, 'Project is not paused'); process.kill(-P.proc.pid, 'SIGCONT'); P.status = 'STARTING'; plog(P, 'manager', 'Resumed'); await waitReady(P, 30000); }
        else { if (act === 'restart') await stopProc(P); P.busy = false; await startProc(P); P.busy = true; await waitReady(P, Math.max(10, P.cfg.startupTimeout) * 1000); }
      } catch (e) { if (act === 'start' || act === 'restart') { P.status = P.exited ? 'FAILED' : P.status; } throw e; }
      finally { P.busy = false; save(); }
      return send(req, res, 200, { ok: true, status: P.status });
    }
    throw new HttpError(404, 'Unknown action: ' + act);
  } catch (e) {
    const code = e.status || 500; if (code >= 500) console.error('[api]', e.message);
    if (!res.headersSent) send(req, res, code, { error: e.message || String(e) });
  }
}

const server = http.createServer((req, res) => { handle(req, res).catch(e => { console.error('[handle]', e); if (!res.headersSent) send(req, res, 500, { error: 'Internal error' }); }); });
server.requestTimeout = 0; server.headersTimeout = 60000; server.keepAliveTimeout = 65000;
server.on('upgrade', (req, socket, head) => { // WebSocket pass-through
  let m = /^\/p\/([A-Za-z0-9_-]+)(\/.*)?$/.exec(new URL(req.url, 'http://x').pathname), P = m && projects.get(m[1]), sub;
  if (m && P) sub = (m[2] || '/') + new URL(req.url, 'http://x').search;
  else { P = findProjectFromReferer(req); sub = req.url; }
  if (!P || P.kind === 'static' || !P.proc || P.exited) { socket.write('HTTP/1.1 502 Bad Gateway\r\n\r\n'); return socket.destroy(); }
  if (P.cfg.private && authed(req) !== 200) { socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n'); return socket.destroy(); }
  const up = net.connect(P.port, '127.0.0.1', () => {
    let h = req.method + ' ' + sub + ' HTTP/1.1\r\n';
    for (let i = 0; i < req.rawHeaders.length; i += 2) h += (/^host$/i.test(req.rawHeaders[i]) ? 'Host: 127.0.0.1:' + P.port : req.rawHeaders[i] + ': ' + req.rawHeaders[i + 1]) + '\r\n';
    up.write(h + '\r\n'); if (head && head.length) up.write(head); socket.pipe(up).pipe(socket);
  });
  up.on('error', () => socket.destroy()); socket.on('error', () => up.destroy());
});

/* ------------------------- watchdog + boot + shutdown ------------------------- */
setInterval(async () => {
  for (const P of projects.values()) {
    if (P.busy || P.kind === 'static' || !P.proc || P.exited || !['SERVING', 'DEGRADED'].includes(P.status)) continue;
    const h = await probe(P);
    if (h.ok) { P.hbFail = 0; if (P.status === 'DEGRADED') { P.status = 'SERVING'; plog(P, 'manager', 'Recovered'); } }
    else if (++P.hbFail >= 3 && P.status === 'SERVING') { P.status = 'DEGRADED'; plog(P, 'manager', 'DEGRADED: health check failing (' + h.text + ')'); }
  }
}, 10000).unref();

async function boot() {
  try { for (const o of JSON.parse(fs.readFileSync(stateFile, 'utf8'))) { const P = newProject(o.id, o.name); Object.assign(P, { port: o.port, desired: o.desired, version: o.version, versions: o.versions || [], plan: o.plan, runtime: o.runtime, kind: o.kind || 'process', guess: o.guess || '', env: o.env || {}, created: o.created, deployedAt: o.deployedAt }); Object.assign(P.cfg, o.cfg || {}); projects.set(P.id, P); try { const lf = path.join(projDir(P.id), 'logs.txt'); if (fs.existsSync(lf) && fs.statSync(lf).size > 5e6) fs.truncateSync(lf, 0); } catch (e) { } } } catch (e) { if (e.code !== 'ENOENT') console.error('state load failed:', e.message); }
  for (const P of projects.values()) if (P.desired === 'running' && P.plan && fs.existsSync(verDir(P.id, P.version))) {
    plog(P, 'manager', 'Manager restarted - starting project again');
    startProc(P).then(() => waitReady(P, Math.max(10, P.cfg.startupTimeout) * 1000)).catch(e => { P.status = 'FAILED'; plog(P, 'manager', 'Auto-start failed: ' + e.message); });
  }
}
function shutdown() { for (const P of projects.values()) if (P.proc && !P.exited) { P._stopping = true; try { process.kill(-P.proc.pid, 'SIGTERM'); } catch (e) { } } setTimeout(() => process.exit(0), 1500); }
process.on('SIGINT', shutdown); process.on('SIGTERM', shutdown);
process.on('uncaughtException', e => console.error('[uncaught]', e)); process.on('unhandledRejection', e => console.error('[unhandled]', e));

server.listen(PORT, HOST, async () => {
  await boot();
  const rt = await runtimes();
  console.log('\n  MBOYA SERVER MANAGER v' + VERSION + ' listening on ' + HOST + ':' + PORT);
  console.log('  Data directory : ' + DATA);
  console.log('  Project URLs   : ' + (URL_MODE === 'port' ? 'http://<host>:<project-port>' : (PUBLIC_URL || 'http://<this-address>:' + PORT) + '/p/<project-id>/'));
  console.log('  Runtimes found : ' + Object.entries(rt).filter(([, v]) => v).map(([k]) => k).join(', '));
  console.log('  Missing        : ' + (Object.entries(rt).filter(([, v]) => !v).map(([k]) => k).join(', ') || 'none'));
  console.log(tokenCreated ? '\n  ACCESS TOKEN (shown once, also saved in ' + tokenFile + '):\n  ' + TOKEN + '\n' : '\n  Access token loaded (' + (E.MANAGER_TOKEN || E.TOKEN ? 'environment' : tokenFile) + ')\n');
  if (!PUBLIC_URL) console.log('  Tip: for access from other devices/continents put this behind HTTPS (see README) and set PUBLIC_URL.\n');
});
