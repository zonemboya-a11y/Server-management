# MBOYA Server Manager

The backend that lets **MBOYA Server Runner** run real server projects — **Python, Java, Go, Rust, PHP, Ruby, .NET, C/C++, Elixir, Dart, Deno, Docker, Node.js and static sites** — instead of only browser-sized ones.

* Install it **once** on any computer or cloud server. It keeps your projects running 24/7, restarts them after crashes and after reboots.
* Open the Runner from **any phone or computer, on any continent**. It only needs the manager's address and token.
* Every project is available at `https://<manager>/p/<project-id>/`, so your own frontend (hosted anywhere) can call your backend at that address.
* Zero npm dependencies. Needs Node.js 18+ on Linux, macOS, WSL, Termux or Docker.

## 1. Quick start

```bash
node server.js
```

On the first start it prints an **access token** (also saved in `data/token`). Then in the Runner: **Settings → Server Manager**, enter the address (for example `http://192.168.1.20:7070`) and the token, press **Test connection**, then **Save Settings**. The top bar shows `Manager: CONNECTED`. Now **Import Project → Deploy** runs the project on the manager machine.

You can also open `http://<manager-address>:7070/` in a browser — the manager serves the Runner itself.

Docker (all common runtimes included): `docker compose up -d --build` after editing the token in `docker-compose.yml`.

## 2. Use it from another device or continent

The manager must be reachable from the internet, and should be behind **HTTPS** (browsers block `http://` managers when the Runner is opened over `https://`). Pick one:

| Option | Steps |
|---|---|
| **Cloudflare Tunnel** (no open ports) | `cloudflared tunnel --url http://localhost:7070` → use the printed `https://….trycloudflare.com` address. For a permanent name create a named tunnel. |
| **VPS + Caddy** (automatic HTTPS) | Point a domain at the server, install Caddy, Caddyfile: `manager.example.com { reverse_proxy localhost:7070 }`. Run the manager with the systemd file or Docker. |
| **Tailscale** (private) | Install Tailscale on the manager machine and on your phone; use `http://<tailscale-name>:7070`. Nothing is exposed publicly. |
| Router port-forward | Forward TCP 7070 to the machine. Works, but add HTTPS (above) before using the token over the internet. |

Optionally set `PUBLIC_URL=https://manager.example.com` so project links always use your public address (otherwise it is detected from the request).

**On an Android phone itself:** install Termux, `pkg install nodejs python golang php ruby openjdk-17`, run `node server.js`, and use `http://localhost:7070`. (Not tested by me; Android limits background processes, so a PC/VPS is more reliable for 24/7 backends.)

## 3. What each language needs on the manager machine

The manager installs dependencies and builds for you, but the language toolchain must exist there (Settings → Test connection lists what it found).

| Project | Needs | Build / start used |
|---|---|---|
| Node.js / TypeScript | node, npm | `npm install`, `npm run build` if present, `npm start` (or main file / `tsx`) |
| Python | python3 + venv | virtualenv + `requirements.txt`; Flask / FastAPI / Django auto-detected |
| Java | JDK, mvn or gradle (or `mvnw`/`gradlew`) | `mvn package` → `java -jar` (Spring Boot gets `--server.port`) |
| Go | go | `go build` → binary |
| Rust | cargo | `cargo build --release` |
| PHP | php (+ composer) | `php -S`, Laravel `artisan serve` |
| Ruby | ruby (+ bundler) | Rails / rackup / plain script |
| .NET | dotnet SDK | `dotnet build` / `dotnet run` |
| C / C++ | gcc/g++ or make | `make` or direct compile |
| Elixir, Dart, Deno | mix, dart, deno | `mix phx.server`, `dart run`, `deno task start` |
| Docker | docker | `docker compose up --build` (best effort) |
| Static sites | nothing | served directly |

Each project receives `PORT` and `HOST` environment variables. If an app ignores them and listens on its own port, the manager detects and follows that port. Edit the start command in **Sandbox → Manifest & Startup** if the automatic one is not right.

## 4. Settings (environment variables)

| Variable | Default | Meaning |
|---|---|---|
| `MANAGER_TOKEN` | generated, stored in `data/token` | Access token (min 16 chars). |
| `MANAGER_PORT` | `7070` | Port of the manager. |
| `PUBLIC_URL` | auto | Public address used in project links. |
| `URL_MODE` | `path` | `path` = projects at `/p/<id>/` behind one port. `port` = `http://host:<project-port>` (open `PROJECT_PORT_MIN–MAX`, default 9000–9999). |
| `DATA_DIR` | `./data` | Projects, versions, logs, encrypted secrets. |
| `CORS_ORIGIN` | `*` | Allowed browser origin for the API. |
| `MAX_UPLOAD_MB` | `300` | Largest project upload. |
| `KEEP_VERSIONS` | `5` | Deployment versions kept for rollback. |
| `ALLOW_ROOT` | – | Set `1` to run as root outside Docker (not recommended). |

## 5. Security — read this

This program **runs code you upload**. That is its job, so treat the token like a server password.

* Use a long random token and HTTPS. Wrong tokens are rate-limited (10 per minute per address).
* It refuses to run as root unless you are in Docker or set `ALLOW_ROOT=1`. Prefer the Docker image or a dedicated unprivileged user.
* Deployed projects run with the manager user's permissions. Do not deploy code you do not trust.
* API keys saved in the Runner are stored encrypted (AES-256-GCM) on the manager and passed to the project as environment variables; they are masked in logs.
* Project URLs (`/p/…`) are public so your frontend can call them. Mark a project private (`PUT /servers/<id>/config {"private":true}`) to require the token.

## 6. Troubleshooting

* **"Cannot reach"** – manager not running, wrong port, firewall/router closed, or you used a private address from another network.
* **Works on Wi-Fi, fails on mobile data** – you used a LAN address (192.168.x.x); use the tunnel/domain/Tailscale address.
* **Blocked / mixed content** – Runner opened over `https://` needs an `https://` manager.
* **Page loads but assets 404** – apps that use absolute paths (`/static/app.js`) work through the Referer fallback; if a project still breaks, set `URL_MODE=port`.
* **"runtime is not installed"** – install the toolchain on the manager machine (or use the Docker image) and deploy again.
